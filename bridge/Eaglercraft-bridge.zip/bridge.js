const http = require('http');
const net = require('net');
const zlib = require('zlib');
const crypto = require('crypto');
const { WebSocketServer } = require('ws');

const WS_PORT = parseInt(process.env.WS_PORT || process.argv[2] || '8081', 10);
let MC_HOST = process.env.MC_HOST || process.argv[3] || '127.0.0.1';
let MC_PORT = parseInt(process.env.MC_PORT || process.argv[4] || '25565', 10);
let PROTOCOL_VERSION = parseInt(process.env.MC_PROTOCOL || process.argv[5] || '777', 10); // 777 = 26.2/26.3

// --- VarInt helpers ---
function readVarInt(buf, offset = 0) {
  let numRead = 0;
  let result = 0;
  let read;
  do {
    if (offset + numRead >= buf.length) return null;
    read = buf[offset + numRead];
    result |= (read & 0x7f) << (7 * numRead);
    numRead++;
    if (numRead > 5) throw new Error('VarInt too big');
  } while ((read & 0x80) !== 0);
  return { value: result, length: numRead };
}

function writeVarInt(value) {
  const bytes = [];
  let v = value >>> 0;
  do {
    let temp = v & 0x7f;
    v >>>= 7;
    if (v !== 0) temp |= 0x80;
    bytes.push(temp);
  } while (v !== 0);
  return Buffer.from(bytes);
}

function writeMcString(str) {
  const strBuf = Buffer.from(str, 'utf8');
  return Buffer.concat([writeVarInt(strBuf.length), strBuf]);
}

function frameMcPacket(packetId, payload = Buffer.alloc(0), compressionThreshold = -1) {
  const idBuf = writeVarInt(packetId);
  const raw = Buffer.concat([idBuf, payload]);

  if (compressionThreshold >= 0) {
    if (raw.length >= compressionThreshold) {
      const compressed = zlib.deflateSync(raw);
      const dataLen = writeVarInt(raw.length);
      const inner = Buffer.concat([dataLen, compressed]);
      return Buffer.concat([writeVarInt(inner.length), inner]);
    } else {
      const dataLen = writeVarInt(0);
      const inner = Buffer.concat([dataLen, raw]);
      return Buffer.concat([writeVarInt(inner.length), inner]);
    }
  }
  return Buffer.concat([writeVarInt(raw.length), raw]);
}

function offlineUuid(username) {
  const md5 = crypto.createHash('md5').update('OfflinePlayer:' + username).digest();
  md5[6] = (md5[6] & 0x0f) | 0x30;
  md5[8] = (md5[8] & 0x3f) | 0x80;
  return md5;
}

const UI_HTML = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Eaglercraft <-> Java Bridge</title>
<style>
  body { font-family: system-ui, sans-serif; background: #12141a; color: #e6edf3; display: flex; justify-content: center; align-items: center; min-height: 100vh; margin: 0; }
  .card { background: #1b1f27; border: 1px solid #30363d; border-radius: 10px; padding: 24px; width: 100%; max-width: 420px; box-shadow: 0 8px 24px rgba(0,0,0,0.4); }
  h1 { font-size: 1.2rem; margin: 0 0 16px; color: #58a6ff; }
  label { display: block; font-size: 0.85rem; color: #8b949e; margin: 12px 0 4px; }
  input { width: 100%; box-sizing: border-box; padding: 9px 10px; border-radius: 6px; border: 1px solid #30363d; background: #0d1117; color: #e6edf3; font-size: 0.95rem; }
  .hint { font-size: 0.75rem; color: #8b949e; margin-top: 4px; }
  button { margin-top: 16px; width: 100%; padding: 10px; border: 0; border-radius: 6px; background: #238636; color: #fff; font-weight: 600; font-size: 0.95rem; cursor: pointer; }
  button:hover { background: #2ea043; }
  .ws-box { margin-top: 16px; padding: 10px; background: #0d1117; border: 1px solid #30363d; border-radius: 6px; font-size: 0.85rem; display: flex; justify-content: space-between; align-items: center; }
  .ws-box code { color: #7ee787; }
  .copy-btn { width: auto; margin: 0; padding: 4px 10px; font-size: 0.75rem; background: #30363d; }
  .status { margin-top: 10px; font-size: 0.85rem; color: #7ee787; min-height: 1.2em; }
</style>
</head>
<body>
<div class="card">
  <h1>Eaglercraft &harr; Java TCP Bridge</h1>
  <label>Target Java Server IP / Domain</label>
  <input id="host" placeholder="e.g. play.pika-network.net">
  <label>Target Java Server Port</label>
  <input id="port" type="number" placeholder="25565">
  <label>Minecraft Protocol Version</label>
  <input id="proto" type="number" placeholder="777">
  <div class="hint">Hints: 26.2/26.3 = 777 | 1.21.4 = 769 | 1.20.1 = 763 | 1.8.8 = 47</div>
  <div style="display:flex;gap:8px;margin-top:16px;">
    <button style="margin-top:0;" onclick="save()">Save &amp; Apply</button>
    <button style="margin-top:0;background:#1f6feb;" onclick="testPing()">Test Ping</button>
  </div>
  <div class="status" id="status"></div>
  <div class="ws-box">
    <span>Eaglercraft URL: <code id="wsUrl"></code></span>
    <button class="copy-btn" onclick="copyWs()">Copy</button>
  </div>
</div>
<script>
  const wsUrl = 'ws://' + location.host;
  document.getElementById('wsUrl').textContent = wsUrl;
  fetch('/api/config').then(r => r.json()).then(c => {
    document.getElementById('host').value = c.mcHost;
    document.getElementById('port').value = c.mcPort;
    document.getElementById('proto').value = c.protocolVersion;
  });
  function save() {
    fetch('/api/config', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        mcHost: document.getElementById('host').value.trim() || '127.0.0.1',
        mcPort: parseInt(document.getElementById('port').value, 10) || 25565,
        protocolVersion: parseInt(document.getElementById('proto').value, 10) || 777
      })
    }).then(r => r.json()).then(c => {
      document.getElementById('status').textContent = 'Updated: ' + c.mcHost + ':' + c.mcPort + ' (protocol ' + c.protocolVersion + ')';
    });
  }
  function copyWs() {
    navigator.clipboard.writeText(wsUrl);
    document.getElementById('status').textContent = 'Copied ' + wsUrl;
  }
  function testPing() {
    const st = document.getElementById('status');
    st.textContent = 'Pinging...';
    fetch('/api/ping').then(r => r.json()).then(p => {
      st.textContent = p.ok ? ('Ping to ' + p.host + ':' + p.port + ' = ' + p.pingMs + ' ms') : ('Ping failed: ' + p.error);
    }).catch(() => { st.textContent = 'Ping request failed'; });
  }
</script>
</body>
</html>`;

// --- HTTP + WebSocket Server ---
const server = http.createServer((req, res) => {
  if (req.method === 'GET' && req.url === '/') {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(UI_HTML);
  } else if (req.method === 'GET' && req.url === '/api/config') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ mcHost: MC_HOST, mcPort: MC_PORT, protocolVersion: PROTOCOL_VERSION, wsPort: WS_PORT }));
  } else if (req.method === 'POST' && req.url === '/api/config') {
    let body = '';
    req.on('data', (c) => (body += c));
    req.on('end', () => {
      try {
        const data = JSON.parse(body);
        if (data.mcHost) MC_HOST = String(data.mcHost).trim();
        if (data.mcPort) MC_PORT = parseInt(data.mcPort, 10) || 25565;
        if (data.protocolVersion) PROTOCOL_VERSION = parseInt(data.protocolVersion, 10) || 777;
        console.log(`[Config] Updated target -> ${MC_HOST}:${MC_PORT} (protocol ${PROTOCOL_VERSION})`);
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ mcHost: MC_HOST, mcPort: MC_PORT, protocolVersion: PROTOCOL_VERSION }));
      } catch {
        res.writeHead(400);
        res.end('Bad JSON');
      }
    });
  } else if (req.method === 'GET' && req.url === '/api/ping') {
    const start = Date.now();
    const sock = net.createConnection({ host: MC_HOST, port: MC_PORT });
    sock.setTimeout(3000);
    const done = (payload) => {
      if (!sock.destroyed) sock.destroy();
      if (!res.writableEnded) {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(payload));
      }
    };
    sock.on('connect', () => done({ ok: true, pingMs: Date.now() - start, host: MC_HOST, port: MC_PORT }));
    sock.on('timeout', () => done({ ok: false, error: 'Timed out (3000ms)' }));
    sock.on('error', (err) => done({ ok: false, error: err.message }));
  } else {
    res.writeHead(404);
    res.end('Not found');
  }
});

const wss = new WebSocketServer({ server });

server.listen(WS_PORT, () => {
  console.log(`Eaglercraft WS <-> Java TCP Bridge`);
  console.log(`  Web UI       : http://localhost:${WS_PORT}  <-- Open this in your browser!`);
  console.log(`  WebSocket    : ws://localhost:${WS_PORT}`);
  console.log(`  Target Java  : ${MC_HOST}:${MC_PORT} (protocol ${PROTOCOL_VERSION})`);
  console.log(`  Note: Target Java server must have online-mode=false`);
});

wss.on('connection', (ws, req) => {
  const remote = req.socket.remoteAddress;
  let state = 'EAGLER_HANDSHAKE'; // EAGLER_HANDSHAKE -> MC_LOGIN -> PLAY
  let tcpSocket = null;
  let tcpBuffer = Buffer.alloc(0);
  let compressionThreshold = -1;
  let username = 'Player';

  const cleanup = () => {
    if (tcpSocket && !tcpSocket.destroyed) tcpSocket.destroy();
    if (ws.readyState === ws.OPEN) ws.close();
  };

  const connectToJavaServer = (playerName) => {
    username = playerName || 'Player';
    console.log(`[${remote}] Connecting "${username}" -> ${MC_HOST}:${MC_PORT}`);

    tcpSocket = net.createConnection({ host: MC_HOST, port: MC_PORT }, () => {
      // 1. Send Minecraft Handshake (0x00)
      const portBuf = Buffer.alloc(2);
      portBuf.writeUInt16BE(MC_PORT, 0);
      const handshakePayload = Buffer.concat([
        writeVarInt(PROTOCOL_VERSION),
        writeMcString(MC_HOST),
        portBuf,
        writeVarInt(2), // Next state: 2 (Login)
      ]);
      tcpSocket.write(frameMcPacket(0x00, handshakePayload));

      // 2. Send Minecraft Login Start (0x00)
      const loginPayload = PROTOCOL_VERSION >= 761
        ? Buffer.concat([writeMcString(username), offlineUuid(username)])
        : writeMcString(username);
      tcpSocket.write(frameMcPacket(0x00, loginPayload));
    });

    tcpSocket.on('data', (chunk) => {
      tcpBuffer = Buffer.concat([tcpBuffer, chunk]);

      while (tcpBuffer.length > 0) {
        const lenInfo = readVarInt(tcpBuffer, 0);
        if (!lenInfo) break;
        const packetLen = lenInfo.value;
        const totalLen = lenInfo.length + packetLen;
        if (tcpBuffer.length < totalLen) break;

        let packetData = tcpBuffer.subarray(lenInfo.length, totalLen);
        tcpBuffer = tcpBuffer.subarray(totalLen);

        if (compressionThreshold >= 0) {
          const dataLenInfo = readVarInt(packetData, 0);
          if (!dataLenInfo) continue;
          const uncompressedLen = dataLenInfo.value;
          const rest = packetData.subarray(dataLenInfo.length);
          packetData = uncompressedLen === 0 ? rest : zlib.inflateSync(rest);
        }

        if (state === 'MC_LOGIN') {
          const idInfo = readVarInt(packetData, 0);
          if (!idInfo) continue;
          const packetId = idInfo.value;

          if (packetId === 0x03) {
            // Set Compression
            const threshInfo = readVarInt(packetData, idInfo.length);
            if (threshInfo) {
              compressionThreshold = threshInfo.value;
              console.log(`[${username}] Compression threshold set to ${compressionThreshold}`);
            }
          } else if (packetId === 0x02) {
            // Login Success -> switch to PLAY
            state = 'PLAY';
            console.log(`[${username}] Logged in! Bridging PLAY packets.`);
            // Protocol 764+ (1.20.2+) requires Login Acknowledged (0x03) before Configuration state
            if (PROTOCOL_VERSION >= 764 && tcpSocket && !tcpSocket.destroyed) {
              tcpSocket.write(frameMcPacket(0x03, Buffer.alloc(0), compressionThreshold));
            }
            // Send Eaglercraft Finish Login (0x09)
            if (ws.readyState === ws.OPEN) {
              ws.send(Buffer.from([0x09]));
            }
          } else if (packetId === 0x00) {
            // Login Disconnect
            console.log(`[${username}] Disconnected during login by Java server.`);
            cleanup();
            return;
          } else if (packetId === 0x01) {
            // Encryption Request -> server is online-mode=true
            console.error(`[${username}] Error: Target server has online-mode=true! Set online-mode=false in server.properties.`);
            cleanup();
            return;
          }
        } else if (state === 'PLAY') {
          // Forward raw uncompressed Minecraft Play packet to Eaglercraft
          if (ws.readyState === ws.OPEN) {
            ws.send(packetData);
          }
        }
      }
    });

    tcpSocket.on('error', (err) => {
      console.error(`[${username}] TCP error: ${err.message}`);
      cleanup();
    });

    tcpSocket.on('close', () => {
      console.log(`[${username}] Java server closed connection.`);
      cleanup();
    });
  };

  ws.on('message', (data, isBinary) => {
    // Handle Eaglercraft MOTD ping
    if (!isBinary) {
      const text = data.toString('utf8').trim();
      if (text.startsWith('Accept: MOTD')) {
        ws.send(JSON.stringify({
          name: 'Eaglercraft Bridge',
          brand: 'fast-eaglercraft',
          vers: 'EaglerBridge/1.0',
          cracked: true,
          time: Date.now(),
          uuid: crypto.randomUUID(),
          type: 'motd',
          data: {
            cache: true,
            motd: [`§aEaglercraft -> Java Bridge`, `§7Target: ${MC_HOST}:${MC_PORT}`],
            icon: false,
            online: 0,
            max: 20,
            players: [],
          },
        }));
        ws.close();
      }
      return;
    }

    const buf = Buffer.isBuffer(data) ? data : Buffer.from(data);
    if (buf.length === 0) return;

    if (state === 'EAGLER_HANDSHAKE') {
      const pktId = buf[0];
      if (pktId === 0x01) {
        // Eaglercraft Client Version -> reply with Server Version (0x02) using handshake v3 (0x0003)
        console.log(`[${remote}] Client 0x01 (${buf.length} bytes): ${buf.subarray(0, 16).toString('hex')}`);
        const protoHi = (PROTOCOL_VERSION >> 8) & 0xff;
        const protoLo = PROTOCOL_VERSION & 0xff;
        const brand = Buffer.from('EaglerBridge', 'utf8');
        const vers = Buffer.from('1.0', 'utf8');
        ws.send(Buffer.concat([
          Buffer.from([0x02, 0x00, 0x03, protoHi, protoLo]),
          Buffer.from([brand.length]), brand,
          Buffer.from([vers.length]), vers,
          Buffer.from([0x00, 0x00, 0x00]), // authType=0, saltLen=0x0000
        ]));
      } else if (pktId === 0x04) {
        // Eaglercraft Client Request Login
        // Format: 0x04, usernameLen(1 byte), username..., [optional password/etc]
        const nameLen = buf[1] || 0;
        const parsedName = buf.subarray(2, 2 + nameLen).toString('utf8').replace(/[^a-zA-Z0-9_]/g, '') || 'Player';
        const uuid = offlineUuid(parsedName);

        // Reply with Server Allow Login (0x05): [0x05, nameLen, name..., 16-byte UUID]
        const nameBuf = Buffer.from(parsedName, 'utf8');
        const allowPkt = Buffer.concat([Buffer.from([0x05, nameBuf.length]), nameBuf, uuid]);
        ws.send(allowPkt);

        state = 'MC_LOGIN';
        connectToJavaServer(parsedName);
      }
    } else if (state === 'PLAY' && tcpSocket && !tcpSocket.destroyed) {
      // Forward Eaglercraft Play packet -> Java TCP (framed + optionally compressed)
      const lenBuf = writeVarInt(buf.length);
      if (compressionThreshold >= 0) {
        if (buf.length >= compressionThreshold) {
          const compressed = zlib.deflateSync(buf);
          const inner = Buffer.concat([writeVarInt(buf.length), compressed]);
          tcpSocket.write(Buffer.concat([writeVarInt(inner.length), inner]));
        } else if (req.method === 'GET' && req.url === '/api/ping') {
    const start = Date.now();
    const sock = net.createConnection({ host: MC_HOST, port: MC_PORT });
    sock.setTimeout(3000);
    const done = (payload) => {
      if (!sock.destroyed) sock.destroy();
      if (!res.writableEnded) {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(payload));
      }
    };
    sock.on('connect', () => done({ ok: true, pingMs: Date.now() - start, host: MC_HOST, port: MC_PORT }));
    sock.on('timeout', () => done({ ok: false, error: 'Timed out (3000ms)' }));
    sock.on('error', (err) => done({ ok: false, error: err.message }));
  } else {
          const inner = Buffer.concat([writeVarInt(0), buf]);
          tcpSocket.write(Buffer.concat([writeVarInt(inner.length), inner]));
        }
      } else if (req.method === 'GET' && req.url === '/api/ping') {
    const start = Date.now();
    const sock = net.createConnection({ host: MC_HOST, port: MC_PORT });
    sock.setTimeout(3000);
    const done = (payload) => {
      if (!sock.destroyed) sock.destroy();
      if (!res.writableEnded) {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(payload));
      }
    };
    sock.on('connect', () => done({ ok: true, pingMs: Date.now() - start, host: MC_HOST, port: MC_PORT }));
    sock.on('timeout', () => done({ ok: false, error: 'Timed out (3000ms)' }));
    sock.on('error', (err) => done({ ok: false, error: err.message }));
  } else {
        tcpSocket.write(Buffer.concat([lenBuf, buf]));
      }
    }
  });

  ws.on('close', cleanup);
  ws.on('error', cleanup);
});
